SET SERVEROUTPUT ON;

-- 1.
CREATE OR REPLACE 
PROCEDURE tasa_reprobracion_graduacion(ANIO number, PROGRAMA varchar2) 
IS
  total_ingresado integer;
  total_retirado_eliminado integer;
  total_graduado integer;
BEGIN
  -- TOTAL ALUMNOS INGRESADOS EN EL AÑO Y PROGRAMA INGRESADO
  SELECT count(*) into total_ingresado
  FROM ESTUDIANTE E, TIENE_ESTADO TE, PROGRAMA P, MATRICULA M
  WHERE E.est_rut = TE.est_rut AND M.est_rut = E.est_rut AND M.pos_codigo = P.pos_codigo
  AND EXTRACT(YEAR FROM TE.fecha_inicio) = ANIO AND P.pos_nombre = PROGRAMA;
  dbms_output.put_line('Total de estudiantes que ingresaron al programa ' || 
  PROGRAMA || ' en el anio ' || ANIO || ' : ' || total_ingresado); 

  -- TOTAL ALUMNOS RETIRADOS O ELIMINADOS EN EL AÑO Y PROGRAMA INGRESADO
  SELECT count(*) into total_retirado_eliminado
  FROM ESTUDIANTE E, TIENE_ESTADO TE, PROGRAMA P, MATRICULA M
  WHERE E.est_rut = TE.est_rut AND M.est_rut = E.est_rut AND M.pos_codigo = P.pos_codigo
  AND EXTRACT(YEAR FROM TE.fecha_inicio) = ANIO AND P.pos_nombre = PROGRAMA
  AND TE.esta_id IN (SELECT esta_id FROM ESTADO WHERE esta_descripcion IN ('Retirado', 'Eliminado'));
  dbms_output.put_line('Total de estudiantes retirados o eliminados del programa ' || 
  PROGRAMA || ' en el anio ' || ANIO || ' : ' || total_retirado_eliminado); 

  -- TOTAL ALUMNOS GRADUADOS EN EL AÑO Y PROGRAMA INGRESADO
  SELECT count(*) into total_graduado
  FROM ESTUDIANTE E, TIENE_ESTADO TE, PROGRAMA P, MATRICULA M
  WHERE E.est_rut = TE.est_rut AND M.est_rut = E.est_rut AND M.pos_codigo = P.pos_codigo
  AND EXTRACT(YEAR FROM TE.fecha_inicio) = ANIO AND P.pos_nombre = PROGRAMA
  AND TE.esta_id IN (SELECT esta_id FROM ESTADO WHERE esta_descripcion = 'Graduado');
  dbms_output.put_line('Total de estudiantes graduados del programa ' || 
  PROGRAMA || ' en el anio ' || ANIO || ' : ' || total_retirado_eliminado); 

  IF total_ingresado = 0 THEN
    dbms_output.put_line('No hay estudiantes ingresados al programa ' || PROGRAMA || ' en el anio ' || ANIO);
  ELSE
    dbms_output.put_line('Tasa de reprobacion del programa ' ||
    PROGRAMA || ' en el anio ' || ANIO || ' : ' || (total_retirado_eliminado / total_ingresado) * 100 || '%');
    dbms_output.put_line('Tasa de graduacion del programa ' ||
    PROGRAMA || ' en el anio ' || ANIO || ' : ' || (total_graduado / total_ingresado) * 100 || '%');
  END IF;
END;

execute tasa_reprobracion_graduacion(2022, 'Tutores');

-- 2.
CREATE OR REPLACE PROCEDURE total_alumnos(programa varchar2, total out integer) 
IS
BEGIN
    SELECT count(*) into total
    FROM ESTUDIANTE E, PROGRAMA P, MATRICULA M
    WHERE M.est_rut = E.est_rut AND M.pos_codigo = P.pos_codigo
    AND P.pos_nombre = programa;
END;

CREATE OR REPLACE PROCEDURE productividad_estudiantes
IS
    CURSOR c1 
        IS SELECT P.pos_nombre, R.rev_descripcion, count(*)
        FROM ARTICULO A, REVISTA R, PUBLICACION PU, GENERA G, ESTUDIANTE E, MATRICULA M, PROGRAMA P
        WHERE R.rev_codigo = A.rev_codigo AND PU.pub_codigo = A.pub_codigo AND
        G.pub_codigo = PU.pub_codigo AND G.est_rut = E.est_rut AND E.est_rut = M.est_rut AND
        M.pos_codigo = P.pos_codigo
        GROUP BY P.pos_nombre, R.rev_descripcion;
    programa varchar2(100);
    indexacion varchar2(100);
    cantidad_articulos integer := 0;
        
    CURSOR c2
        IS SELECT P.pos_nombre, count(*)
        FROM PROGRAMA P, MATRICULA M, ESTUDIANTE E, GENERA G, PUBLICACION PU
        WHERE P.pos_codigo = M.pos_codigo AND M.est_rut = E.est_rut 
        AND E.est_rut = G.est_rut AND G.pub_codigo = PU.pub_codigo
        GROUP BY P.pos_nombre;
    cantidad_publicaciones integer;
    alumnos integer;
    
    CURSOR c3
        IS SELECT P.pos_nombre, count(*)
        FROM ARTICULOCONF AC, PUBLICACION PU, GENERA G, ESTUDIANTE E, MATRICULA M, PROGRAMA P
        WHERE P.pos_codigo = M.pos_codigo AND M.est_rut = E.est_rut AND E.est_rut = G.est_rut AND
        G.pub_codigo = PU.pub_codigo AND PU.pub_codigo = AC.pub_codigo
        GROUP BY P.pos_nombre;
BEGIN
    open c1;
    fetch c1 into programa, indexacion, cantidad_articulos;
    while c1%found LOOP
        dbms_output.put_line('En el programa ' || programa || ' hay ' || cantidad_articulos || ' articulos con la indexacion ' || indexacion);
        fetch c1 into programa, indexacion, cantidad_articulos;
    END LOOP;
    close c1;
    
    open c3;
    fetch c3 into programa, cantidad_articulos;
    while c3%found LOOP
        dbms_output.put_line('En el programa ' || programa || ' hay ' || cantidad_articulos || ' articulos por conferencia');
        fetch c3 into programa, cantidad_articulos;
    END LOOP;
    close c3;
    
    open c2;
    fetch c2 into programa, cantidad_publicaciones;
    while c2%found LOOP
        total_alumnos(programa, alumnos);
        dbms_output.put_line('El programa ' || programa || ' tiene un promedio de publicaciones de: '
        || (cantidad_publicaciones / alumnos) * 100 || '%');
        fetch c2 into programa, cantidad_publicaciones;
    END LOOP;
    close c2;
END;

execute productividad_estudiantes();

-- 3.
CREATE USER ADMINISTRADOR IDENTIFIED BY admin;

GRANT CREATE SESSION TO ADMINISTRADOR;
GRANT CREATE ANY TABLE TO ADMINISTRADOR;
GRANT SELECT ANY TABLE TO ADMINISTRADOR;
GRANT INSERT ANY TABLE TO ADMINISTRADOR;
GRANT UPDATE ANY TABLE TO ADMINISTRADOR;

GRANT DBA TO ADMINISTRADOR;

CREATE USER ANALISTA IDENTIFIED BY analista;

GRANT CREATE SESSION TO ANALISTA;
GRANT SELECT ON ACADEMICO TO ANALISTA;
GRANT SELECT ON PUBLICACION TO ANALISTA;

-- 4.
CREATE BITMAP INDEX IN_ESTADO 
ON ESTADO(ESTA_DESCRIPCION);

CREATE BITMAP INDEX IN_PROGRAMA 
ON PROGRAMA(POS_NOMBRE);


